const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors())
// const apiRouter = require('./apiRouter');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'notesdb'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});


app.get('/', (req, res) => {
    return res.json("from backend");

});
app.get('/notes', (req, res) => {
    const sql = "SELECT * FROM notes";
    db.query(sql, (err, data) => {
      if (err) {
        console.error('Error fetching notes:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
      res.json(data);
    });
  });
  

app.post('/notes', (req, res) => {

  const { id, content } = req.body;
  
 
  if (!id || !content) {
    return res.status(400).json({ error: 'Missing id or content in request body' });
  }


  const sql = `INSERT INTO notes (id, content) VALUES (${id}, '${content}')`;
  db.query(sql, (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(201).json({ message: 'Note added successfully' });
    }
  });
});
app.delete('/notes/:id', (req, res) => {
  const id = req.params.id;
  db.query('DELETE FROM notes WHERE id = ?', id, (err, results) => {
    if (err) throw err;
    res.sendStatus(200);
  });
});

app.listen(3000, () => {
  console.log("listening");
});
