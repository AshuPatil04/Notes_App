import React from 'react';
import { Link,BrowserRouter,Route,Routes } from 'react-router-dom';
import Addnote from './addnote';

const App = () => {
  return (
    <div>

      {/* <Link to="/addnote">
        <button>Add Note</button>
      </Link> */}
      <BrowserRouter>
      
    <Routes>
      <Route path='/' element={<Addnote />} ></Route>
      {/* <Route path='/addnote' element={<Addnote />} ></Route> */}

    </Routes>
    </BrowserRouter>
    </div>
  );
};

export default App;
