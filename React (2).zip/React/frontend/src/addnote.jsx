import React, { useState, useEffect } from 'react';
import axios from 'axios';


const NotePage = () => {
  const [id, setId] = useState('');
  const [content, setContent] = useState('');
  const [notes, setNotes] = useState([]);

  const generateRandomId = () => {
    return Math.floor(Math.random() * 1000); // Generate a random number between 0 and 999999
  };

  const fetchNotes = async () => {
    try {
      const response = await axios.get('http://localhost:3000/notes');
      setNotes(response.data);
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  const addNote = async () => {
    const id = generateRandomId();
    try {
      await axios.post('http://localhost:3000/notes', { id, content });
      setId('');
      setContent('');
      fetchNotes();
    } catch (error) {
      console.error('Error adding note:', error);
    }
  };

  const deleteNote = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/notes/${id}`);
      fetchNotes();
    } catch (error) {
      console.error('Error deleting note:', error);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  return (
    // <div>
    //   <h1>Notes</h1>
    //   <form onSubmit={(e) => {
    //     e.preventDefault();
    //     addNote();
    //   }}>
    //     <input type='text' value={id} onChange={(e) => setId(e.target.value)} placeholder='ID' />
    //     <input type='text' value={content} onChange={(e) => setContent(e.target.value)} placeholder='Content' />
    //     <button type='submit'>Add Note</button>
    //   </form>
    //   <ul>
    //     {notes.map(note => (
    //       <li key={note.id}>
    //         <div>
    //           <h2>{note.id}</h2>
    //           <p>{note.content}</p>
    //         </div>
    //         <button onClick={() => deleteNote(note.id)}>Delete</button>
    //       </li>
    //     ))}
    //   </ul>
    // </div>
    
    <div style={{ fontFamily: 'Arial, sans-serif', textAlign: 'center' }}>
      
    <h1>Notes</h1>
    <form onSubmit={(e) => {
      e.preventDefault();
      addNote();
    }}>
      <input
        type='text'
        value={id}
        onChange={(e) => setId(e.target.value)}
        placeholder='ID'
        hidden
        style={{
          width: '100%',
          padding: '10px',
          marginBottom: '10px',
          borderRadius: '5px',
          border: '1px solid #ccc',
          boxSizing: 'border-box',
        }}
      />
      <input
        type='text'
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder='Note'
        style={{
          width: '100%',
          padding: '10px',
          marginBottom: '10px',
          borderRadius: '5px',
          border: '1px solid #ccc',
          boxSizing: 'border-box',
        }}
      />
      <button
        type='submit'
        style={{
          width: '100%',
          padding: '10px 20px',
          backgroundColor: '#007bff',
          color: '#fff',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
      >
        Add Note
      </button>
    </form>
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      {notes.map(note => (
        <div key={note.id} style={{ width: '300px', margin: '10px', padding: '10px', border: '1px solid #ccc', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
          <h2 hidden>{note.id}</h2>
          <p>{note.content}</p>
          <button
            onClick={() => deleteNote(note.id)}
            style={{
              width: '100%',
              padding: '10px 20px',
              backgroundColor: '#dc3545',
              color: '#fff',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
            }}
          >
            Delete
          </button>
        </div>
      ))}
    </div>
  </div>
  
  

  );
};

export default NotePage;
